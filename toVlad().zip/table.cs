﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyExcelMAUIApp
{
    public class Table
    {
        private Dictionary<string, Cell> cells = new Dictionary<string, Cell>();

        public Cell GetCell(string cellAddress)
        {
            if (cells.ContainsKey(cellAddress))
            {
                return cells[cellAddress];
            }
            else
            {
                var newCell = new Cell();
                cells[cellAddress] = newCell;
                return newCell;
            }
        }


        public void SetCellValue(string cellAddress, double value)
        {
            var cell = GetCell(cellAddress);
            cell.Value = value;
        }

        public void SetCellExpression(string cellAddress, string expression)
        {
            var cell = GetCell(cellAddress);
            cell.Expression = expression;
        }

        public bool IsCircularReference(string cellAddress)
        {
            return IsCircularReference(cellAddress, new List<string>(), new List<string>());
        }

        private bool IsCircularReference(string cellAddress, List<string> visitedCells, List<string> currentChain)
        {
            if (visitedCells.Contains(cellAddress))
            {
                // Circular reference detected
                return true;
            }

            visitedCells.Add(cellAddress);
            currentChain.Add(cellAddress);

            var cell = GetCell(cellAddress);

            foreach (var dependentCellAddress in cell.ObservedBy)
            {
                if (currentChain.Contains(dependentCellAddress))
                {
                    // Circular reference detected within the current chain
                    return true;
                }

                if (IsCircularReference(dependentCellAddress, visitedCells, currentChain))
                {
                    return true;
                }
            }

            visitedCells.Remove(cellAddress);
            currentChain.Remove(cellAddress);
            return false;
        }

        public List<string> GetCellAddresses()
        {
            return cells.Keys.ToList();
        }
        public void Clear()
        {
            cells.Clear();
        }
        public void SetCell(string cellAddress, Cell cell)
        {
            cells[cellAddress] = cell;
        }
    }
}
