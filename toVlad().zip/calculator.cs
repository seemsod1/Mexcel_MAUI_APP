﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyExcelMAUIApp
{
    class Calculator
    {
        public Table CellTable { get; set; } = new Table();

        public double DefineAndExecute(string cellAddress, string query)
        {
            // Check if the query is a valid cell reference
                if (IsCellReference(query))
                {
                    Cell referenceCell = CellTable.GetCell(query);
                    return referenceCell.Value;
                }

                // If the query is not a valid cell reference, handle it as a direct value
                if (double.TryParse(query, out var directValue))
                {
                    // Update the cell's value directly
                    Cell currentCell = CellTable.GetCell(cellAddress);
                    currentCell.Value = directValue;

                    // Clear the expression
                    currentCell.Expression = null;

                    return directValue;
                }

                // Return NaN for invalid input
            
            return 0;
        }
        public bool IsCellReference(string cellContent)
        {
            if (!string.IsNullOrEmpty(cellContent))
            {
                if (Regex.IsMatch(cellContent, "^[A-Z]+[1-9][0-9]*$", RegexOptions.IgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
