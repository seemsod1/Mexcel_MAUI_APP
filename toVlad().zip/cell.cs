﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyExcelMAUIApp
{
    public class Cell
    {
        public double Value { get; set; }
        public string Expression { get; set; }
        public string Depends_on { get; set; }
        public List<string> ObservedBy { get; } = new List<string>();
    }

}
