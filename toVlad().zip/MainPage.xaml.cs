﻿using CommunityToolkit.Maui.Storage;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Compatibility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Grid = Microsoft.Maui.Controls.Grid;
namespace MyExcelMAUIApp
{
    public partial class MainPage : ContentPage
    {

        private Calculator calculator = new Calculator();

        private string currentCellAddress;

        const int CountColumn = 4; // кількість стовпчиків (A to Z)
        const int CountRow = 4; // кількість рядків

        IFileSaver fileSaver;
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        public MainPage(IFileSaver fileSaver)
        {
            InitializeComponent();
            this.fileSaver = fileSaver;
            CreateGrid();
        }
        //створення таблиці
        private void CreateGrid()
        {
            AddColumnsAndColumnLabels();
            AddRowsAndCellEntries();

        }
        private void AddColumnsAndColumnLabels()
        {
            // Додати стовпці та підписи для стовпців
            for (int col = 0; col < CountColumn + 1; col++)
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                if (col > 0)
                {
                    var label = new Label
                    {
                        Text = GetColumnName(col),

                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Center

                    };

                    Grid.SetRow(label, 0);
                    Grid.SetColumn(label, col);
                    grid.Children.Add(label);

                }
            }
        }
        private void AddRowsAndCellEntries()
        {
            // Add rows, row labels, and cell entries
            for (int row = 0; row < CountRow; row++)
            {
                grid.RowDefinitions.Add(new RowDefinition());
                // Add a label for the row number
                var label = new Label
                {
                    Text = (row + 1).ToString(),
                    VerticalOptions = LayoutOptions.Center,
                    HorizontalOptions = LayoutOptions.Center
                };
                Grid.SetRow(label, row + 1);
                Grid.SetColumn(label, 0);
                grid.Children.Add(label);

                // Add cell entries (Entry) for content
                for (int col = 0; col < CountColumn; col++)
                {
                    var entry = new Entry
                    {
                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Center
                    };

                    var cellAddress = GetColumnName(col + 1) + (row + 1);

                    // Retrieve the cell data from the Table class
                    Cell cell = calculator.CellTable.GetCell(cellAddress);

                    if (cell != null)
                    {
                        // Check if the cell has an expression, and set Entry text accordingly
                        //if (!string.IsNullOrEmpty(cell.Expression))
                        //{
                        //    entry.Text = cell.Expression;
                       // }
                       // else
                      //  {
                            entry.Text = cell.Value.ToString();
                       // }
                    }

                    entry.Unfocused += Entry_Unfocused;

                    Grid.SetRow(entry, row + 1);
                    Grid.SetColumn(entry, col + 1);
                    grid.Children.Add(entry);
                }
            }
        }

        private string GetColumnName(int colIndex)
        {
            int dividend = colIndex;
            string columnName = string.Empty;
            while (dividend > 0)
            {
                int modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo) + columnName;
                dividend = (dividend - modulo) / 26;

            }
            return columnName;
        }
        // викликається, коли користувач вийде зі зміненої клітинки (втратить фокус)
        private void Entry_Unfocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var row = Grid.GetRow(entry) - 1;
            var col = Grid.GetColumn(entry) - 1;
            var cellAddress = GetColumnName(col + 1) + (row + 1);

            var cell = calculator.CellTable.GetCell(cellAddress);

            if (!string.IsNullOrEmpty(entry.Text))
            {
                // Check if the entered text is a valid cell reference
                if (calculator.IsCellReference(entry.Text))
                {
                    if (string.Compare(entry.Text, cellAddress) == 0)
                    {
                        DisplayAlert("ERROR", "SELFDEPENDENCE", "OK");
                    }
                    else
                    {
                        // Handle the case where the entered text is a cell reference
                        string referenceAddress = entry.Text.ToUpper(); // Normalize the reference to uppercase
                        cell.Expression = referenceAddress;
                        if (!string.IsNullOrEmpty(cell.Depends_on))
                        {
                            var rcell = calculator.CellTable.GetCell(cell.Depends_on);
                            if (rcell.ObservedBy.Contains(cellAddress))
                            {
                                rcell.ObservedBy.Remove(cellAddress);
                            }
                            cell.Depends_on = referenceAddress;
                        }
                        else
                        {
                            cell.Depends_on = referenceAddress;
                        }
                        var refcell = calculator.CellTable.GetCell(referenceAddress);
                        refcell.ObservedBy.Add(cellAddress);
                        // Calculate the value of the cell based on the reference
                        double newValue = calculator.DefineAndExecute(cellAddress, referenceAddress);
                        cell.Value = newValue;
                        entry.Text = newValue.ToString();
                        List<string> str = new List<string>();
                        UpdateDependentCells(cellAddress, str);
                    }
                }
                else
                {
                    // Handle the case where the entered text is a direct value
                    if (double.TryParse(entry.Text, out var directValue))
                    {
                        cell.Expression = directValue.ToString(); // Clear the expression
                        cell.Value = directValue;
                        entry.Text = directValue.ToString();
                        List<string> str = new List<string>();
                        UpdateDependentCells(cellAddress, str);
                    }
                }
            }
        }
        
        private void UpdateDependentCells(string cellAddress, List<string> visitedChain)
        {
            // Initialize a set to keep track of visited cells during the update
            var visitedCells = new HashSet<string>();

            // Queue to process cells with dependencies
            var queue = new Queue<string>();
            queue.Enqueue(cellAddress);

            while (queue.Count > 0)
            {
                var currentAddress = queue.Dequeue();
                var currentCell = calculator.CellTable.GetCell(currentAddress);

                if (currentCell != null)
                {
                    visitedCells.Add(currentAddress);

                    // Iterate through the cells that depend on the current cell
                    foreach (var dependentAddress in currentCell.ObservedBy)
                    {
                        if (visitedChain.Contains(dependentAddress))
                        {
                            // Circular reference detected
                            DisplayAlert("ERROR", "RER", "OK");
                        }

                        if (!visitedCells.Contains(dependentAddress))
                        {
                            visitedChain.Add(dependentAddress);  // Add the current cell to the chain
                                                                 // Calculate the value of the dependent cell
                            double newValue = calculator.DefineAndExecute(dependentAddress, currentCell.Expression);
                            var dependentCell = calculator.CellTable.GetCell(dependentAddress);
                            dependentCell.Value = newValue;
                            // Add the dependent cell to the processing queue
                            queue.Enqueue(dependentAddress);
                            visitedChain.Remove(dependentAddress);  // Remove the current cell from the chain
                        }
                    }
                }
            }
        }




        private void CalculateButton_Clicked(object sender, EventArgs e)
        {
            // Обробка кнопки "Порахувати"
        }
        private async void SaveButton_Clicked(object sender, EventArgs e)
        {
            try
            {
                // Create a dictionary to store the cell data
                var cellData = new Dictionary<string, string>();

                // Iterate through all cells in the Table
                foreach (var cellAddress in calculator.CellTable.GetCellAddresses())
                {
                    var cell = calculator.CellTable.GetCell(cellAddress);

                    if (cell != null)
                    {
                        // Serialize the cell data (you might want to adjust this based on your data structure)
                        string cellJson = JsonSerializer.Serialize(new
                        {
                            Value = cell.Value,
                            Expression = cell.Expression,
                            DependenciesOn = cell.Depends_on,
                            DependenciesBy = cell.ObservedBy
                        });

                        cellData[cellAddress] = cellJson;
                    }
                }

                // Serialize the cell data dictionary to JSON
                string json = JsonSerializer.Serialize(cellData);

                // Create a memory stream to store the JSON data
                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));

                // Save the JSON data to a file using the file saver
                var path = await fileSaver.SaveAsync("table.json", stream, cancellationTokenSource.Token);

                // Display a message to the user
                await DisplayAlert("Success", $"The table has been saved to {path}", "OK");
            }
            catch (Exception ex)
            {
                // Handle the exception
                await DisplayAlert("Error", $"An error occurred while saving the table: {ex.Message}", "OK");
            }
        }



        private async void ReadButton_Clicked(object sender, EventArgs e)
        {
            bool shouldRead = await DisplayAlert("Confirmation", "Do you want to load data from a file?", "Yes", "No");

            if (shouldRead)
            {
                try
                {
                    var options = new PickOptions
                    {
                        // You can adjust the FileTypes as needed, or simply omit it for all files
                    };

                    var result = await FilePicker.PickAsync(options);

                    if (result != null)
                    {
                        string filePath = result.FullPath;
                        string json = File.ReadAllText(filePath);

                        // Deserialize the JSON data to your Calculator's CellTable
                        var loadedData = JsonSerializer.Deserialize<Dictionary<string, Cell>>(json);

                        // Clear the existing data in your Table
                        calculator.CellTable.Clear();

                        // Populate your Calculator's CellTable with the loaded data
                        foreach (var (cellAddress, cell) in loadedData)
                        {
                            calculator.CellTable.SetCell(cellAddress, cell);
                        }

                        // Update the UI for the loaded cell data
                        //UpdateCellValuesInUI();
                    }
                }
                catch (Exception ex)
                {
                    // Handle the exception
                    await DisplayAlert("Error", $"An error occurred while reading the table: {ex.Message}", "OK");
                }
            }
        }
        private void UpdateCellValuesInUI()
        {
            foreach (var cellAddress in calculator.CellTable.GetCellAddresses())
            {
              //  var cell = calculator.CellTable.GetCell(cellAddress);
                //var entry = FindEntryForCellAddress(cellAddress);

              //  if (entry != null)
               // {
                    // Update the UI entry with the cell's value
//entry.Text = cell.Value.ToString();
               // }
            }
        }


        private async void ExitButton_Clicked(object sender, EventArgs e)
        {
            bool answer = await DisplayAlert("Підтвердження", "Ви дійсно хочете вийти?",
            "Так", "Ні");
            if (answer)
            {
                System.Environment.Exit(0);
            }
        }
        private async void HelpButton_Clicked(object sender, EventArgs e)
        {
            await DisplayAlert("Довідка", "Лабораторна робота 1. Студента Василя Іваненка",
            "OK");
        }
        private void DeleteRowButton_Clicked(object sender, EventArgs e)
        {
            if (grid.RowDefinitions.Count > 1)
            {
                int lastRowIndex = grid.RowDefinitions.Count - 1;
                grid.RowDefinitions.RemoveAt(lastRowIndex);
                grid.Children.RemoveAt(lastRowIndex * (CountColumn + 1)); // Remove label
                for (int col = 0; col < CountColumn; col++)
                {
                    grid.Children.RemoveAt((lastRowIndex * CountColumn) + col + 1); 
                }
            }
        }
        private void DeleteColumnButton_Clicked(object sender, EventArgs e)
        {
            if (grid.ColumnDefinitions.Count > 1)
            {
                int lastColumnIndex = grid.ColumnDefinitions.Count - 1;
                grid.ColumnDefinitions.RemoveAt(lastColumnIndex);
                grid.Children.RemoveAt(lastColumnIndex); // Remove label
                for (int row = 0; row < CountRow; row++)
                {

                    grid.Children.RemoveAt(row * (CountColumn + 1) + lastColumnIndex +
                    1); // Remove entry
                }
            }
        }
        private void AddRowButton_Clicked(object sender, EventArgs e)
        {
            int newRow = grid.RowDefinitions.Count;
            // Add a new row definition
            grid.RowDefinitions.Add(new RowDefinition());
            // Add label for the row number
            var label = new Label
            {
                Text = newRow.ToString(),
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };
            Grid.SetRow(label, newRow);
            Grid.SetColumn(label, 0);
            grid.Children.Add(label);
            // Add entry cells for the new row
            for (int col = 0; col < CountColumn; col++)
            {
                var entry = new Entry
                {
                    Text = "",

                    VerticalOptions = LayoutOptions.Center,
                    HorizontalOptions = LayoutOptions.Center

                };
                entry.Unfocused += Entry_Unfocused;
                Grid.SetRow(entry, newRow);
                Grid.SetColumn(entry, col + 1);
                grid.Children.Add(entry);
            }
        }
        private void AddColumnButton_Clicked(object sender, EventArgs e)
        {
            int newColumn = grid.ColumnDefinitions.Count;
            // Add a new column definition
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            // Add label for the column name
            var label = new Label
            {
                Text = GetColumnName(newColumn),
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center
            };
            Grid.SetRow(label, 0);
            Grid.SetColumn(label, newColumn);
            grid.Children.Add(label);
            // Add entry cells for the new column
            for (int row = 0; row < CountRow; row++)
            {
                var entry = new Entry
                {
                    Text = "",
                    VerticalOptions = LayoutOptions.Center,
                    HorizontalOptions = LayoutOptions.Center

                };
                entry.Unfocused += Entry_Unfocused;
                Grid.SetRow(entry, row + 1);

                Grid.SetColumn(entry, newColumn);
                grid.Children.Add(entry);
            }
        }
    }



}